package com.codingshuttle.projects.lovable_clone.dto.project;

public record FileContentResponse(
        String path,
        String content
) {
}
