package com.codingshuttle.projects.lovable_clone.enums;

public enum ProjectRole {
    EDITOR, VIEWER, OWNER
}
