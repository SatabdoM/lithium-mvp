package com.codingshuttle.projects.lovable_clone.enums;

public enum SubscriptionStatus {
    ACTIVE, TRIALING, CANCELED, PAST_DUE, INCOMPLETE
}
