package com.codingshuttle.projects.lovable_clone.dto.subscription;

public record PortalResponse(String portalUrl) {
}
