package com.codingshuttle.projects.lovable_clone.enums;

public enum PreviewStatus {
    CREATING, RUNNING, FAILED, TERMINATED
}
