package com.codingshuttle.projects.lovable_clone.enums;

public enum MessageRole {
    USER, ASSISTANT, SYSTEM, TOOL
}
