package com.codingshuttle.projects.lovable_clone.dto.member;

import com.codingshuttle.projects.lovable_clone.enums.ProjectRole;

public record UpdateMemberRoleRequest(ProjectRole role) {
}
