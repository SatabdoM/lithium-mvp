package com.codingshuttle.projects.lovable_clone.dto.project;

public record ProjectRequest(
        String name
) {
}
