package com.codingshuttle.projects.lovable_clone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LovableCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
